import torch

# 查看 PyTorch 版本
print(f"PyTorch version: {torch.__version__}")

# 查看 CUDA 是否可用
cuda_available = torch.cuda.is_available()
print(f"CUDA available: {cuda_available}")

# 查看 CUDA 版本（如果可用）
if cuda_available:
    print(f"CUDA version: {torch.version.cuda}")
else:
    print("CUDA is not available.")
