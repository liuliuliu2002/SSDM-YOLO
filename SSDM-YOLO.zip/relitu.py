import torch
import cv2
import numpy as np
import matplotlib.pyplot as plt
from ultralytics.models import YOLO  # 假设你有YOLOv8的实现文件
from ultralytics.utils.torch_utils import select_device
import os

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"


def generate_heatmap():
    # 选择设备，默认使用GPU
    device = select_device('cuda:0')

    # 加载预训练的YOLOv8模型
    model = YOLO(r'E:\ultralytics-main\runs\train\yolov8n-visdrone-car\weights\best.pt')  # 使用你自己的预训练模型路径

    # 确保模型处于推理模式
    model.eval()
    print(f'Model in training mode: {model.training}')  # 应该输出 False，表示在推理模式

    # 获取YOLOv8模型的最后卷积层
    last_conv = model.model.model[-1]  # 获取最后的卷积层（具体根据模型架构）

    # 定义梯度钩子函数
    def backward_hook(module, grad_input, grad_output):
        global gradients
        gradients = grad_output[0]

    # 注册钩子来获取卷积层的梯度
    last_conv.register_backward_hook(backward_hook)

    # 读取并预处理输入图像
    img_path = r'E:\网站下载\VisDrone2019\train\images\0000008_01999_d_0000040.jpg'  # 替换为你的图像路径
    img = cv2.imread(img_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_resized = cv2.resize(img, (640, 640))  # 适配YOLOv8输入尺寸
    img_tensor = torch.from_numpy(img_resized).float().unsqueeze(0).to(device) / 255.0

    # 进行推理
    output = model(img_tensor)  # 获取模型输出

    # 反向传播，生成梯度
    output[0].sum().backward()  # 对模型输出的预测结果做求和，并执行反向传播

    # 获取卷积层的输出特征图
    conv_output = last_conv.output[0].detach().cpu().numpy()

    # 计算加权梯度
    weights = torch.mean(gradients, dim=[2, 3], keepdim=True)  # 均值池化，得到每个通道的权重
    cam = torch.sum(weights * conv_output, dim=1).squeeze()  # 通道加权求和

    # 将CAM缩放到与原图相同的尺寸
    cam = cv2.resize(cam.numpy(), (img.shape[1], img.shape[0]))
    cam = np.maximum(cam, 0)  # 去除负值
    cam = cam / cam.max()  # 归一化到[0, 1]

    # 生成热力图并与原图叠加
    heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    overlayed_img = cv2.addWeighted(img, 0.5, heatmap, 0.5, 0)

    # 可视化结果
    plt.imshow(overlayed_img)
    plt.axis('off')
    plt.show()


# 这个条件用于确保多进程问题不出现
if __name__ == '__main__':
    generate_heatmap()
