import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO
import os
os.environ['KMP_DUPLICATE_LIB_OK']='TRUE'

if __name__ == '__main__':
    model = YOLO(r'E:\ultralytics-main\ultralytics\cfg\models\v8\yolov8n.yaml')
    # odel.load('yolov8n.pt') # loading pretrain weights
    model.train(data=r'E:\ultralytics-main\ultralytics\cfg\datasets\VisDrone.yaml',
                cache=False,
                imgsz=640,
                epochs=200,
                batch=4,
                close_mosaic=0,
                workers=4,
                optimizer='SGD', # using SGD
                # patience=0, # close earlystop
                # resume=True, # 断点续训,YOLO初始化时选择last.pt
                # amp=False, # close amp
                # fraction=0.2,
                project='runs/train',
                name='yolov8n-visdrone-car',
                )


